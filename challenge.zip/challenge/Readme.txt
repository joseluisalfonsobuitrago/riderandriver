To do test is neccesary install the next gems
-json
-sinatra
-rest-client
-pg 

Running code locally

You need use postman or anotherone software to send the json trouhg POST 

1. Open de prompt console that you use for execute the principal file rider_select_driverdb.rb 
2. Take the port that show the console. Normally is 4567. Construct a link like this http://localhost:4567/
3. Use the link to do the manual tests. Put this link in some software like postman
4. For request a driver add requiereservice to the end of the link and write a JSON like this
{
  "user": "andres",
  "longitude": "-75.575973",
  "latitude": "6.213813",
  "estado": "true"
}
if all it is okey you must to receive a JSON like this 
{
    "user": "andres",
    "longitude": "-75.575973",
    "latitude": "6.213813",
    "estado": true,
    "driver": "Ricardo",
    "estadoviaje": true
}

or 

{
    "error": "The rider is on board now",
    "estado": false
}

if the rider is on board. If you need request another trip you must finish the current trip

5. For end the trip you must to add requiereservice to the end of the link. You not need write a JSON
6. The response is a JSON too and look like this 
{
    "finallongitude": "-75.575074",
    "finallatitude": "6.243813",
    "driver": "Ricardo",
    "price": 6851,
    "currency": "COP",
    "estadoviaje": false
}
Or if you do not has an active trip the JSON respose will be
{
    "error": "there are not active trips",
    "estadoviaje": true
}

Running the tests

The file have 3 differents kind of tests. For execute you need pen de prompt console that you use for execute the test. For example ruby complete_test.rb
and you can watch the execution result. You must remember the trip status for understand the test. It is no neccesary execute the local rider_select_driverdb becouse
the test run in heraku

-Complete test take an random values of riders or drivers to the data base and start the travel and inmediatly finish the trip and do the payment

-Requiere driver test take a randome values of riders and drivers and start the travel 

-Finish ride test charges the trip and ends it


The Heroku URL is http://challengejulian.herokuapp.com 

