require 'minitest/autorun'
require 'json'
require 'rest-client'
require 'pg'
$conn = PG.connect(host: 'ec2-54-243-92-68.compute-1.amazonaws.com', dbname: 'd6hr6ujqsnfncl', user: 'rvuntufzkhmkqr', password: '20af1d255814272bad341a4296a30f59eb6bf2242bdda1ceeb3a0341b7752ffc' )
def requireservice
rows = $conn.exec("SELECT * FROM public.riders")
r=rand(1..5)

response = RestClient::Request.new({
  method: :post,
  url: 'http://challengejulian.herokuapp.com/requireservice',
  payload: {user: "#{rows[r]['username']}",longitude: "#{rows[r]['longitude']}",
  latitude: "#{rows[r]['latitude']}",estado: "#{rows[r]['status']}"}.to_json}).execute
  responsetoken= JSON.parse response.to_str
  return responsetoken['estadoviaje']
end

def finisharide
    response = RestClient::Request.new({
      method: :post,
      url: 'http://challengejulian.herokuapp.com/finisharide'}).execute
      responsetoken= JSON.parse response.to_str
      return responsetoken['estadoviaje']
    end

class Testrider < Minitest::Test
    def test_minitest
        assert_equal true, requireservice
        assert_equal false, finisharide
    end
end