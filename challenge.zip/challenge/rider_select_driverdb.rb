require 'json'
require 'sinatra'
require 'rest-client'
require 'time'
require 'pg'


$canrequireservice = true
$timestart=0
$json =" "
$riderstatus= false
$finishtrip
$localization = []
$closer =0
    

$conn = PG.connect(host: 'ec2-54-243-92-68.compute-1.amazonaws.com', dbname: 'd6hr6ujqsnfncl', user: 'rvuntufzkhmkqr', password: '20af1d255814272bad341a4296a30f59eb6bf2242bdda1ceeb3a0341b7752ffc' )


post '/requireservice' do
    content_type :json
    data = JSON.parse request.body.read
    $data1 = [data['user'],data['longitude'],data['latitude'],data['estado']]
    if($riderstatus==false)
        rows = $conn.exec("SELECT * FROM public.drivers")
        rows.each do |row|
            $d=distance(row['latitude'].to_f,row['longitude'].to_f,$data1[2].to_f, $data1[1].to_f)    
            $localization[(row['id'].to_i - 1)]=$d;
           selectdriver($localization,row['driver'])
        end
        $closer =0
        $localization = []
        $riderstatus=!$riderstatus
        $timestart=Time.now.strftime("%s")
        request = {:user => $data1[0],:longitude => $data1[1],:latitude => $data1[2],:estado => $canrequireservice,:driver => $driver,:estadoviaje => true}.to_json
        responsetoken= JSON.parse request.to_str
        $json=request
        $canrequireservice=!$canrequireservice
        return $json
    else
        request = {:error => "The rider is on board now",:estado => $canrequireservice}.to_json
        return request
    end
end

post '/finisharide' do
    content_type :json
    $json
    if($riderstatus==true)
    $riderstatus=!$riderstatus
    $canrequireservice=!$canrequireservice
    total_minute=((Time.now.strftime("%s").to_i-$timestart.to_f)/60.0)
    finisharide=JSON.parse $json.to_str
    finaltrip = {:finallongitude => "-75.575074",:finallatitude => "6.243813",}.to_json
    finallocalization=JSON.parse finaltrip.to_str
    d=distance(finisharide['latitude'].to_f,finisharide['longitude'].to_f,finallocalization['finallatitude'].to_f,finallocalization['finallongitude'].to_f)
    finaltrip = { :finallongitude => "-75.575074",:finallatitude => "6.243813",:driver => finisharide['driver'],:price => amount(d,total_minute),:currency => "COP",:estadoviaje => !finisharide['estadoviaje']}.to_json
    payment(amount(d,total_minute),"COP",finisharide['user'])
    return finaltrip
    else
        finaltrip = {:error => "there are not active trips",:estadoviaje => true}.to_json 
        return finaltrip
end
end

def distance(lat1,lon1,lat2,lon2)
    dlat=(((lat2-lat1).abs)*3.141592653589793)/180
    dlon=(((lon2-lon1).abs)*3.141592653589793)/180
    a= (Math.sin(dlat/2))**2 + (Math.cos(lat1)*Math.cos(lat2)*((Math.sin(dlon/2))**2))
    c= 2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a))
    return 6378*c 
end

def amount(distance,triptime)
    return (1000*distance + 200*triptime + 3500).round
end

def selectdriver(distance,driver)
    if($closer != distance.min)    
        $closer= distance.min
        $driver = driver
    end
end


def payment(amount,currency,name)
    ref=rand(1...1000545)
    response = RestClient::Request.new({
        method: :post,
        url: 'https://sandbox.wompi.co/v1/transactions',
        payload: {

            amount_in_cents: amount*100,
            currency: "#{currency}",
            customer_email: "#{name + "@gmail.com.net"}",
            payment_source_id: 12097,
            payment_method: 
            {
                installments: 1
            },
            reference: "#{1212+ref}"
        
        }.to_json,
        headers: {authorization: 'Bearer prv_test_qWpxUoPqA0fPUrUel6Ucc661w1ypqzDo'}
         }).execute  
end